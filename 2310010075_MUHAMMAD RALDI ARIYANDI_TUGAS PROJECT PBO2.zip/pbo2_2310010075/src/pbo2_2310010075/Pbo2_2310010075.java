/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pbo2_2310010075;
//import frame.framePasien;
//import frame.frameDokter;
//import frame.frameObat;
//import frame.frameSatuan;
import frame.frameMenu;
/**
 *
 * @author ASUS
 */
public class Pbo2_2310010075 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //new framePasien().setVisible(true);
        //new frameDokter().setVisible(true);
        //new frameObat().setVisible(true);
        //new frameSatuan().setVisible(true);
        new frameMenu().setVisible(true);
    }
    
}
