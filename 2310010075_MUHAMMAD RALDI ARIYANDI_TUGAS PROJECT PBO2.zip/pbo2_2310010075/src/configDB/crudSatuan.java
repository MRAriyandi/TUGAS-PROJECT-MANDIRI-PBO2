/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ASUS
 */
public class crudSatuan {
    
    private String namaDB = "pbo2_2310010075";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection connect;
    
    // Variabel Satuan
    public int VAR_ID_SATUAN;
    public String VAR_NAMA_SATUAN;
    
    public boolean validasi = false;
    
    public crudSatuan() {
        try {
            Driver mysqldriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(mysqldriver);
            connect = DriverManager.getConnection(url,username,password);
            System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
            
        }
    }
    
    public void simpanSatuan01(String ID, String namaSatuan){
        try {
            String sql = "insert into satuan(id_satuan, nama_satuan) "
                    + "values('"+ID+"', '"+namaSatuan+"')";
            
            String cekPrimary = "select * from satuan where id_satuan = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Satuan Sudah Terdaftar");
                this.VAR_NAMA_SATUAN = data.getString("nama_satuan");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_SATUAN= null;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanSatuan02(String ID, String namaSatuan){
        try {
            String sql = "insert into satuan(id_satuan, nama_satuan) value(?, ?)";
                String cekPrimary = "select * from satuan where id_satuan = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Satuan Sudah Terdaftar");
                this.VAR_NAMA_SATUAN = data.getString("nama_satuan");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_SATUAN = null;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, namaSatuan);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahSatuan01(String ID, String namaSatuan){
        try {
            String sql = "update satuan set nama_satuan = '"+namaSatuan+"' where id_satuan = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahSatuan02(String ID, String namaSatuan){
        try {
            String sql = "update satuan set nama_satuan =? where id_satuan = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, namaSatuan);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusSatuan01(String ID){
        try {
            String sql = "delete from satuan where id_satuan = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusSatuan02(String ID){
        try {
            String sql = "delete from satuan where id_satuan = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataSatuan (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Satuan");
            modelTable.addColumn("Nama Satuan");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.connect);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
    
}
