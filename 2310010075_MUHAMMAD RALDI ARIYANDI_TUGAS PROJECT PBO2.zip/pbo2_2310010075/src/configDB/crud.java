/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ASUS
 */
public class crud {
    
    private String namaDB = "pbo2_2310010075";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection connect;
    
    // Variabel Satuan
    public int VAR_ID_SATUAN;
    public String VAR_NAMA_SATUAN;
    
    // Variabel Obat
    public int VAR_ID_OBAT;
    public String VAR_ID_SATUAN_FK;
    public String VAR_NAMA_OBAT;
    public int VAR_HARGA_SATUAN;
    public int VAR_STOK_OBAT;
    
    // Variabel Dokter
    public int VAR_ID_DOKTER;
    public String VAR_NAMA_DOKTER;
    public String VAR_SPESIALISASI;
    public String VAR_NO_HP;
    
    // Variabel Pasien
    public int VAR_ID_PASIEN;
    public String VAR_NAMA_PASIEN;
    public String VAR_ALAMAT_PASIEN;
    public int VAR_UMUR;
    public String VAR_JENIS_KELAMIN;
    
    
    
    public boolean validasi = false;
    
    public crud() {
        try {
            Driver mysqldriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(mysqldriver);
            connect = DriverManager.getConnection(url,username,password);
            System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
            
        }
    }
    
    public void simpanSatuan01(String ID, String namaSatuan){
        try {
            String sql = "insert into satuan(id_satuan, nama_satuan) "
                    + "values('"+ID+"', '"+namaSatuan+"')";
            
            String cekPrimary = "select * from satuan where id_satuan = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Satuan Sudah Terdaftar");
                this.VAR_NAMA_SATUAN = data.getString("nama_satuan");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_SATUAN= null;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanSatuan02(String ID, String namaSatuan){
        try {
            String sql = "insert into satuan(id_satuan, nama_satuan) value(?, ?)";
                String cekPrimary = "select * from satuan where id_satuan = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Satuan Sudah Terdaftar");
                this.VAR_NAMA_SATUAN = data.getString("nama_satuan");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_SATUAN = null;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, namaSatuan);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahSatuan01(String ID, String namaSatuan){
        try {
            String sql = "update satuan set nama_satuan = '"+namaSatuan+"' where id_satuan = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahSatuan02(String ID, String namaSatuan){
        try {
            String sql = "update satuan set nama_satuan =? where id_satuan = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, namaSatuan);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusSatuan01(String ID){
        try {
            String sql = "delete from satuan where id_satuan = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusSatuan02(String ID){
        try {
            String sql = "delete from satuan where id_satuan = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
  
    public void simpanObat01(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "insert into obat(id_obat, id_satuan, nama_obat, harga_satuan, stok_obat) "
                    + "values('"+ID+"', '"+idSatuanFK+"', '"+namaObat+"', '"+hargaSatuan+"', '"+stokObat+"')";
            
            String cekPrimary = "select * from obat where id_obat = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Obat Sudah Terdaftar");
                this.VAR_ID_SATUAN_FK = data.getString("id_satuan");
                this.VAR_NAMA_OBAT = data.getString("nama_obat");
                this.VAR_HARGA_SATUAN = data.getInt("harga_satuan");
                this.VAR_STOK_OBAT = data.getInt("stok_obat");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_ID_SATUAN_FK= null;
                this.VAR_NAMA_OBAT = null;
                this.VAR_HARGA_SATUAN = 0;
                this.VAR_STOK_OBAT = 0;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanObat02(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "insert into obat(id_obat, id_satuan, nama_obat, harga_satuan, stok_obat) value(?, ?, ?, ?, ?)";
                String cekPrimary = "select * from obat where id_obat = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Obat Sudah Terdaftar");
                this.VAR_ID_SATUAN_FK = data.getString("id_satuan");
                this.VAR_NAMA_OBAT = data.getString("nama_obat");
                this.VAR_HARGA_SATUAN = data.getInt("harga_satuan");
                this.VAR_STOK_OBAT = data.getInt("stok_obat");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_ID_SATUAN_FK = null;
                this.VAR_NAMA_OBAT = null;
                this.VAR_HARGA_SATUAN = 0;
                this.VAR_STOK_OBAT = 0;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, idSatuanFK);
                perintah.setString(3, namaObat);
                perintah.setString(4, hargaSatuan);
                perintah.setString(5, stokObat);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahObat01(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "update obat set id_satuan = '"+idSatuanFK+"', nama_obat = '"+namaObat+"'"
                    + ", harga_satuan = '"+hargaSatuan+"'" 
                    + ", stok_obat = '"+stokObat+"' where id_obat = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahObat02(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "update obat set id_satuan =?, nama_obat =?, harga_satuan =?, stok_obat =? where id_obat = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, idSatuanFK);
            perintah.setString(2, namaObat);
            perintah.setString(3, hargaSatuan);
            perintah.setString(4, stokObat);
            perintah.setString(5, ID);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public void hapusObat01(String ID){
        try {
            String sql = "delete from obat where id_obat = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusObat02(String ID){
        try {
            String sql = "delete from obat where id_obat = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    
    public void simpanDokter01(String ID, String namaDokter, String spesialisasi, String noHp){
        try {
            String sql = "insert into dokter(id_dokter, nm_dokter, spesialisasi, no_hp) "
                    + "values('"+ID+"', '"+namaDokter+"', '"+spesialisasi+"', '"+noHp+"')";
            
            String cekPrimary = "select * from dokter where id_dokter = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Dokter Sudah Terdaftar");
                this.VAR_NAMA_DOKTER = data.getString("nm_dokter");
                this.VAR_SPESIALISASI = data.getString("spesialisasi");
                this.VAR_NO_HP = data.getString("no_hp");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_DOKTER = null;
                this.VAR_SPESIALISASI = null;
                this.VAR_NO_HP = null;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanDokter02(String ID, String namaDokter, String spesialisasi, String noHp){
        try {
            String sql = "insert into dokter(id_dokter, nm_dokter, spesialisasi, no_hp) value(?, ?, ?, ?)";
                String cekPrimary = "select * from dokter where id_dokter = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Dokter Sudah Terdaftar");
                this.VAR_NAMA_DOKTER = data.getString("nm_dokter");
                this.VAR_SPESIALISASI = data.getString("spesialisasi");
                this.VAR_NO_HP = data.getString("no_hp");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_DOKTER = null;
                this.VAR_SPESIALISASI  = null;
                this.VAR_NO_HP = null;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, namaDokter);
                perintah.setString(3, spesialisasi);
                perintah.setString(4, noHp);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahDokter01(String ID, String namaDokter, String spesialisasi, String noHp){
        try {
            String sql = "update dokter set nm_dokter = '"+namaDokter+"'"
                    + ", spesialisasi = '"+spesialisasi+"'"
                    + ", no_hp = '"+noHp+"'" 
                    + " where id_dokter = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahDokter02(String ID, String namaDokter, String spesialisasi, String noHp){
        try {
            String sql = "update dokter set nm_dokter =?, spesialisasi =?, no_hp =? where id_dokter = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, namaDokter);
            perintah.setString(2, spesialisasi);
            perintah.setString(3, noHp);
            perintah.setString(4, ID);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusDokter01(String ID){
        try {
            String sql = "delete from dokter where id_dokter = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusDokter02(String ID){
        try {
            String sql = "delete from dokter where id_dokter = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    
    public void simpanPasien01(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "insert into pasien(id_pasien, nama_pasien, alamat, umur, jenis_kelamin) "
                    + "values('"+ID+"', '"+namaPasien+"', '"+alamatPasien+"', '"+umur+"', '"+jenisKelamin+"')";
            
            String cekPrimary = "select * from pasien where id_pasien = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Pasien Sudah Terdaftar");
                this.VAR_NAMA_PASIEN = data.getString("nama_pasien");
                this.VAR_ALAMAT_PASIEN = data.getString("alamat");
                this.VAR_UMUR = data.getInt("umur");
                this.VAR_JENIS_KELAMIN = data.getString("jenis_kelamin");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_PASIEN = null;
                this.VAR_ALAMAT_PASIEN = null;
                this.VAR_UMUR = 0;
                this.VAR_JENIS_KELAMIN = null;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanPasien02(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "insert into pasien(id_pasien, nama_pasien, alamat, umur, jenis_kelamin) "
                    + "value(?, ?, ?, ?, ?)";
                String cekPrimary = "select * from pasien where id_pasien = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Pasien Sudah Terdaftar");
                this.VAR_NAMA_PASIEN = data.getString("nama_pasien");
                this.VAR_ALAMAT_PASIEN = data.getString("alamat");
                this.VAR_UMUR = data.getInt("umur");
                this.VAR_JENIS_KELAMIN = data.getString("jenis_kelamin");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_PASIEN = null;
                this.VAR_ALAMAT_PASIEN  = null;
                this.VAR_UMUR = 0;
                this.VAR_JENIS_KELAMIN = null;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, namaPasien);
                perintah.setString(3, alamatPasien);
                perintah.setString(4, umur);
                perintah.setString(5, jenisKelamin);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahPasien01(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "update pasien set nama_pasien = '"+namaPasien+"', alamat = '"+alamatPasien+"'"
                    + ", umur = '"+umur+"'" 
                    + ", jenis_kelamin = '"+jenisKelamin+"' where id_pasien = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahPasien02(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "update pasien set nama_pasien =?, alamat =?, umur =?, jenis_kelamin =? where id_pasien = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, namaPasien);
            perintah.setString(2, alamatPasien);
            perintah.setString(3, umur);
            perintah.setString(4, jenisKelamin);
            perintah.setString(5, ID);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public void hapusPasien01(String ID){
        try {
            String sql = "delete from pasien where id_pasien = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusPasien02(String ID){
        try {
            String sql = "delete from pasien where id_pasien = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataSatuan (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Satuan");
            modelTable.addColumn("Nama Satuan");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void tampilDataObat (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Obat");
            modelTable.addColumn("ID Satuan");
            modelTable.addColumn("Nama Obat");
            modelTable.addColumn("Harga Satuan");
            modelTable.addColumn("Stok Obat");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void tampilDataDokter (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Dokter");
            modelTable.addColumn("Nama Dokter");
            modelTable.addColumn("Spesialisasi");
            modelTable.addColumn("No Hp");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void tampilDataPasien (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Pasien");
            modelTable.addColumn("Nama Pasien");
            modelTable.addColumn("Alamat");
            modelTable.addColumn("Umur");
            modelTable.addColumn("Jenis Kelamin");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.connect);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
    
}
