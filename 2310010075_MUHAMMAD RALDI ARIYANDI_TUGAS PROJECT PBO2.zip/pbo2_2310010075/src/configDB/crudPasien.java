/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ASUS
 */
public class crudPasien {
    
    private String namaDB = "pbo2_2310010075";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection connect;
    
    // Variabel Pasien
    public int VAR_ID_PASIEN;
    public String VAR_NAMA_PASIEN;
    public String VAR_ALAMAT_PASIEN;
    public int VAR_UMUR;
    public String VAR_JENIS_KELAMIN;
    
    public boolean validasi = false;
    
    public crudPasien() {
        try {
            Driver mysqldriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(mysqldriver);
            connect = DriverManager.getConnection(url,username,password);
            System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
            
        }
    }
    
    public void simpanPasien01(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "insert into pasien(id_pasien, nama_pasien, alamat, umur, jenis_kelamin) "
                    + "values('"+ID+"', '"+namaPasien+"', '"+alamatPasien+"', '"+umur+"', '"+jenisKelamin+"')";
            
            String cekPrimary = "select * from pasien where id_pasien = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Pasien Sudah Terdaftar");
                this.VAR_NAMA_PASIEN = data.getString("nama_pasien");
                this.VAR_ALAMAT_PASIEN = data.getString("alamat");
                this.VAR_UMUR = data.getInt("umur");
                this.VAR_JENIS_KELAMIN = data.getString("jenis_kelamin");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_PASIEN = null;
                this.VAR_ALAMAT_PASIEN = null;
                this.VAR_UMUR = 0;
                this.VAR_JENIS_KELAMIN = null;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanPasien02(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "insert into pasien(id_pasien, nama_pasien, alamat, umur, jenis_kelamin) "
                    + "value(?, ?, ?, ?, ?)";
                String cekPrimary = "select * from pasien where id_pasien = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Pasien Sudah Terdaftar");
                this.VAR_NAMA_PASIEN = data.getString("nama_pasien");
                this.VAR_ALAMAT_PASIEN = data.getString("alamat");
                this.VAR_UMUR = data.getInt("umur");
                this.VAR_JENIS_KELAMIN = data.getString("jenis_kelamin");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_NAMA_PASIEN = null;
                this.VAR_ALAMAT_PASIEN  = null;
                this.VAR_UMUR = 0;
                this.VAR_JENIS_KELAMIN = null;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, namaPasien);
                perintah.setString(3, alamatPasien);
                perintah.setString(4, umur);
                perintah.setString(5, jenisKelamin);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahPasien01(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "update pasien set nama_pasien = '"+namaPasien+"', alamat = '"+alamatPasien+"'"
                    + ", umur = '"+umur+"'" 
                    + ", jenis_kelamin = '"+jenisKelamin+"' where id_pasien = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahPasien02(String ID, String namaPasien, String alamatPasien, String umur, String jenisKelamin){
        try {
            String sql = "update pasien set nama_pasien =?, alamat =?, umur =?, jenis_kelamin =? where id_pasien = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, namaPasien);
            perintah.setString(2, alamatPasien);
            perintah.setString(3, umur);
            perintah.setString(4, jenisKelamin);
            perintah.setString(5, ID);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public void hapusPasien01(String ID){
        try {
            String sql = "delete from pasien where id_pasien = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusPasien02(String ID){
        try {
            String sql = "delete from pasien where id_pasien = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataPasien (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Pasien");
            modelTable.addColumn("Nama Pasien");
            modelTable.addColumn("Alamat");
            modelTable.addColumn("Umur");
            modelTable.addColumn("Jenis Kelamin");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.connect);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
    
}
