/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package configDB;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Driver;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
import javax.swing.table.DefaultTableModel;
import java.io.File;
import java.util.Set;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.design.JRDesignQuery;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ASUS
 */
public class crudObat {
    
    private String namaDB = "pbo2_2310010075";
    private String url = "jdbc:mysql://localhost:3306/" + namaDB;
    private String username = "root";
    private String password = "";
    private Connection connect;
    
    // Variabel Obat
    public int VAR_ID_OBAT;
    public String VAR_ID_SATUAN_FK;
    public String VAR_NAMA_OBAT;
    public int VAR_HARGA_SATUAN;
    public int VAR_STOK_OBAT;
    
    public boolean validasi = false;
    
    public crudObat() {
        try {
            Driver mysqldriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(mysqldriver);
            connect = DriverManager.getConnection(url,username,password);
            System.out.print("Berhasil dikoneksikan");
        } catch (SQLException error) {
            JOptionPane.showMessageDialog(null, error.getMessage());
            
        }
    }
    
    public void simpanObat01(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "insert into obat(id_obat, id_satuan, nama_obat, harga_satuan, stok_obat) "
                    + "values('"+ID+"', '"+idSatuanFK+"', '"+namaObat+"', '"+hargaSatuan+"', '"+stokObat+"')";
            
            String cekPrimary = "select * from obat where id_obat = '"+ID+"'";
            
            Statement check = connect.createStatement();
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Obat Sudah Terdaftar");
                this.VAR_ID_SATUAN_FK = data.getString("id_satuan");
                this.VAR_NAMA_OBAT = data.getString("nama_obat");
                this.VAR_HARGA_SATUAN = data.getInt("harga_satuan");
                this.VAR_STOK_OBAT = data.getInt("stok_obat");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_ID_SATUAN_FK= null;
                this.VAR_NAMA_OBAT = null;
                this.VAR_HARGA_SATUAN = 0;
                this.VAR_STOK_OBAT = 0;
                Statement perintah = connect.createStatement();
            perintah.execute(sql);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanObat02(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "insert into obat(id_obat, id_satuan, nama_obat, harga_satuan, stok_obat) value(?, ?, ?, ?, ?)";
                String cekPrimary = "select * from obat where id_obat = ;";
            
            PreparedStatement check = connect.prepareStatement(cekPrimary);
            ResultSet data = check.executeQuery(cekPrimary);
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Obat Sudah Terdaftar");
                this.VAR_ID_SATUAN_FK = data.getString("id_satuan");
                this.VAR_NAMA_OBAT = data.getString("nama_obat");
                this.VAR_HARGA_SATUAN = data.getInt("harga_satuan");
                this.VAR_STOK_OBAT = data.getInt("stok_obat");
                this.validasi = true;
            } else {
                this.validasi = false;
                this.VAR_ID_SATUAN_FK = null;
                this.VAR_NAMA_OBAT = null;
                this.VAR_HARGA_SATUAN = 0;
                this.VAR_STOK_OBAT = 0;
                PreparedStatement perintah = connect.prepareStatement(sql);
                perintah.setString(1, ID);
                perintah.setString(2, idSatuanFK);
                perintah.setString(3, namaObat);
                perintah.setString(4, hargaSatuan);
                perintah.setString(5, stokObat);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null,"Berhasil disimpan");
            }
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahObat01(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "update obat set id_satuan = '"+idSatuanFK+"', nama_obat = '"+namaObat+"'"
                    + ", harga_satuan = '"+hargaSatuan+"'" 
                    + ", stok_obat = '"+stokObat+"' where id_obat = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahObat02(String ID, String idSatuanFK, String namaObat, String hargaSatuan, String stokObat){
        try {
            String sql = "update obat set id_satuan =?, nama_obat =?, harga_satuan =?, stok_obat =? where id_obat = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, idSatuanFK);
            perintah.setString(2, namaObat);
            perintah.setString(3, hargaSatuan);
            perintah.setString(4, stokObat);
            perintah.setString(5, ID);
            
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil diubah");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        
    }
    
    public void hapusObat01(String ID){
        try {
            String sql = "delete from obat where id_obat = '"+ID+"'";
                    
            Statement perintah = connect.createStatement();
            perintah.execute(sql);
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusObat02(String ID){
        try {
            String sql = "delete from obat where id_obat = ?";
                    
            PreparedStatement perintah = connect.prepareStatement(sql);
            perintah.setString(1, ID);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null,"Data berhasil dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataObat (JTable komponenTable, String SQL){
        try {
            Statement perintah = connect.createStatement();
            ResultSet data = perintah.executeQuery(SQL);
            ResultSetMetaData meta = data.getMetaData();
            int jumKolom = meta.getColumnCount();
            DefaultTableModel modelTable = new DefaultTableModel();
            modelTable.addColumn("ID Obat");
            modelTable.addColumn("ID Satuan");
            modelTable.addColumn("Nama Obat");
            modelTable.addColumn("Harga Satuan");
            modelTable.addColumn("Stok Obat");
            modelTable.getDataVector().clear();
            modelTable.fireTableDataChanged();
            while (data.next() ) {
                Object[] row = new Object[jumKolom];
                for(int i = 1; i <= jumKolom; i++ ){
                    row [i - 1] = data.getObject(i);
                }
                modelTable.addRow(row);
                
            }
            komponenTable.setModel(modelTable);
        } catch (Exception e) {
            
        }
    }
    
    public void cetakLaporan(String fileLaporan, String SQL){
        try {
            File file = new File(fileLaporan);
            JasperDesign jasDes = JRXmlLoader.load(file);
            JRDesignQuery query = new JRDesignQuery();
            query.setText(SQL);
            jasDes.setQuery(query);
            JasperReport jr = JasperCompileManager.compileReport(jasDes);
            JasperPrint jp = JasperFillManager.fillReport(jr, null, this.connect);
            JasperViewer.viewReport(jp);
            
        } catch (Exception e) {
        }
    }
    
}
